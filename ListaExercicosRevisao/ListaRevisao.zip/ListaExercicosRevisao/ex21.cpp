#include <iostream>
using namespace std;

void imprimirTexto(){
    cout << "Hola Alexandre!!!!\n";
}

int main(){
    imprimirTexto();
    return 0;
}